var UnoAppManifest = {
    displayName: "UnoApp1"
}
